
constructBlock("MyCustomBlock", 5, 3, 4, 0, "mod/a.png", 0, 0, 32, 32)
puts("Mod is loaded!")

